import { Component } from "react";

export default class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("ErrorBoundary caught:", error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error">
          <h2>Oops! Something went wrong.</h2>
          <p>Please go back and try again.</p>
        </div>
      );
    }
    return this.props.children;
  }
}
