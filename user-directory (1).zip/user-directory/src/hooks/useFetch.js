import { useState, useEffect } from "react";

export default function useFetch(url) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) {
          throw new Error(`Request failed with status ${response.status}`);
        }

        setData(await response.json());
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(err.message);
        }
      } finally {
        // Skip this if the request was cancelled, otherwise we would
        // show "no data" before the real request has finished
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    load();

    // Cleanup: cancel the request if the page or URL changes
    return () => controller.abort();
  }, [url]);

  return { data, loading, error };
}
