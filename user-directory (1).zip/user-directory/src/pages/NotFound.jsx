export default function NotFound() {
  return (
    <div>
      <h1>404: Page not found</h1>
      <p>Sorry, we could not find the page you were looking for.</p>
    </div>
  );
}
