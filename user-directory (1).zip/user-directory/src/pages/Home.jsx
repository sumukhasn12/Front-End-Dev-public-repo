export default function Home() {
  return (
    <div>
      <h1>Welcome</h1>
      <p>This is the home page of the User Directory.</p>
    </div>
  );
}
