export default function About() {
  return (
    <div>
      <h1>About</h1>
      <p>This app was built to learn routing, API calls, and performance in React.</p>
    </div>
  );
}
