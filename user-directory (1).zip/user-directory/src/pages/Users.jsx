import { Link } from "react-router-dom";
import useFetch from "../hooks/useFetch";

export default function Users() {
  const { data: users, loading, error } = useFetch(
    "https://jsonplaceholder.typicode.com/users"
  );

  if (loading) return <p>Loading users...</p>;
  if (error) return <p className="error">Something went wrong: {error}</p>;
  if (!users || users.length === 0) return <p>No users found.</p>;

  return (
    <div>
      <h1>Users</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            <Link to={`/users/${user.id}`}>{user.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
