import { useParams, Link, useNavigate } from "react-router-dom";
import useFetch from "../hooks/useFetch";

export default function UserDetail() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { data: user, loading, error } = useFetch(
    `https://jsonplaceholder.typicode.com/users/${userId}`
  );

  // Uncomment the next 3 lines to test the ErrorBoundary at /users/999
  // if (userId === "999") {
  //   throw new Error("Test crash!");
  // }

  if (loading) return <p>Loading user...</p>;
  if (error) return <p className="error">Something went wrong: {error}</p>;

  return (
    <div>
      <h1>{user.name}</h1>
      <p><strong>Username:</strong> {user.username}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <p><strong>Phone:</strong> {user.phone}</p>
      <p><strong>City:</strong> {user.address.city}</p>
      <p><strong>Company:</strong> {user.company.name}</p>
      <Link to="/users">&larr; Back to users</Link>
      <br /><br />
      <button onClick={() => navigate(-1)}>Go back (previous page)</button>
    </div>
  );
}
