# User Directory (React + Vite + React Router)

A small beginner project that demonstrates routing, API integration, lazy loading, and error boundaries.

![Users page showing ten users](screenshots/08-users-list.png)

## Run it

```bash
npm install
npm run dev
```

Then open the link shown in the terminal (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Learn step by step

The full beginner guide, with screenshots of the expected output at every step, is in [GUIDE.md](GUIDE.md).
